---
title: 'Homepage'
meta_title: 'Hugo Serif Theme'
description: "Serif is a modern business theme for Hugo."
intro_image: "images/illustrations/pointing.svg"
intro_image_absolute: true
intro_image_hide_on_mobile: true
---

# Serif - A Hugo Business Theme.

Serif contains content types for a typical business website. The theme is fully responsive, blazing fast and artfully illustrated.
